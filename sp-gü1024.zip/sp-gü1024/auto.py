class Auto:

    def __init__(self, farbe):
        self.farbe = farbe
    
    def fahre(self, tempo): #Methode
        print("Das "+self.farbe+" Auto faehrt Tempo: " + str(tempo)) 

if __name__ == "__main__":
    auto1 = Auto("gruen") #Objekt
    print(auto1.farbe)
    auto1.farbe = "blau"
    print(auto1.farbe)
    auto1.fahre(130)
    
