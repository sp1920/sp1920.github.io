import unittest
from example_module import square

class SquareTest(unittest.TestCase):
    
    def testCalculation(self):
        self.assertEqual(square(2),4)
        self.assertEqual(square(-2),4)
        
