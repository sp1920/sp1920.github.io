def square(x):

    """Return the square of x

    >>> square(2)
    4

    """
    
    return x * x
