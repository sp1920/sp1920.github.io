#
print("Hello World")

def square(x):
    return x * x

class X:
    def fct(self):
        print(1)

a = 0
print(square(a))
c = X()
c.fct()
